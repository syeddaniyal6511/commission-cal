<script setup>
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import useCalculations from '../../composables/useCalculations.js';

const route = useRoute();

const { calculations, pagination, loading, error, fetchCalculations } = useCalculations();

const page       = ref(1);
const expanded   = ref([]);

const contractNo = route.query.contract_no ?? `#${route.params.id}`;

onMounted(() => load());

async function load() {
    await fetchCalculations(route.params.id, page.value);
    if (calculations.value.length > 0 && !expanded.value.includes(calculations.value[0].id)) {
        expanded.value = [calculations.value[0].id];
    }
}

async function changePage(p) {
    if (p < 1 || p > pagination.value?.last_page) return;
    page.value = p;
    expanded.value = [];
    await load();
}

function toggle(id) {
    if (expanded.value.includes(id)) {
        expanded.value = expanded.value.filter(x => x !== id);
    } else {
        expanded.value = [...expanded.value, id];
    }
}

function isExpanded(id) {
    return expanded.value.includes(id);
}

function formatNum(val, decimals = 4) {
    return Number(val).toLocaleString('en-GB', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
    });
}

function formatDate(str) {
    return new Date(str).toLocaleString('en-GB', {
        year: 'numeric', month: 'short', day: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
    });
}

const INPUT_KEYS = ['AnnualUsage', 'ContractValue', 'ContractLength', 'RiskScore'];

function inputSteps(steps) {
    return steps?.filter(s => s.type === 'input') ?? [];
}
function computedSteps(steps) {
    return steps?.filter(s => s.type === 'computed') ?? [];
}
function resultStep(steps) {
    return steps?.find(s => s.type === 'result') ?? null;
}
</script>

<template>
    <div class="space-y-6 max-w-3xl mx-auto">

        <!-- Header -->
        <div class="flex items-center gap-3">
            <RouterLink
                :to="{ name: 'contracts' }"
                class="text-gray-400 hover:text-gray-600 transition"
            >
                <font-awesome-icon icon="arrow-left" />
            </RouterLink>
            <div>
                <h1 class="text-xl font-semibold text-gray-900">Calculation history</h1>
                <p class="text-sm font-mono text-gray-500 mt-0.5">{{ contractNo }}</p>
            </div>
        </div>

        <!-- Loading -->
        <div v-if="loading" class="flex items-center justify-center py-20 text-gray-400 text-sm gap-2">
            <font-awesome-icon icon="circle-notch" spin />
            Loading history…
        </div>

        <!-- Error -->
        <div v-else-if="error" class="bg-red-50 text-red-600 text-sm rounded-xl px-5 py-4 border border-red-100">
            {{ error }}
        </div>

        <!-- Empty -->
        <div v-else-if="!calculations.length" class="flex flex-col items-center justify-center py-20 text-gray-400 gap-2">
            <font-awesome-icon icon="clock" class="text-3xl" />
            <p class="text-sm">No calculations yet for this contract.</p>
        </div>

        <!-- Calculations list -->
        <div v-else class="space-y-3">
            <div
                v-for="calc in calculations"
                :key="calc.id"
                class="bg-white rounded-xl border border-gray-200 overflow-hidden"
            >
                <!-- Card header — always visible -->
                <button
                    class="w-full flex items-center justify-between px-5 py-4 text-left hover:bg-gray-50 transition"
                    @click="toggle(calc.id)"
                >
                    <div class="flex items-center gap-4">
                        <div class="flex items-center justify-center w-8 h-8 rounded-full bg-brand-orange/10 text-brand-orange text-xs font-bold shrink-0">
                            #{{ calc.id }}
                        </div>
                        <div>
                            <div class="flex items-center gap-2">
                                <span class="text-base font-semibold text-gray-900">
                                    £{{ formatNum(calc.commission) }}
                                </span>
                                <span class="text-xs bg-gray-100 text-gray-600 rounded px-2 py-0.5 font-mono">
                                    v{{ calc.formula_version ?? '?' }}
                                </span>
                            </div>
                            <p class="text-xs text-gray-500 mt-0.5">{{ formatDate(calc.created_at) }}</p>
                        </div>
                    </div>
                    <font-awesome-icon
                        :icon="isExpanded(calc.id) ? 'angle-up' : 'angle-down'"
                        class="text-gray-400 shrink-0"
                    />
                </button>

                <!-- Trace — expandable -->
                <Transition
                    enter-active-class="transition-all ease-out duration-200 overflow-hidden"
                    enter-from-class="max-h-0 opacity-0"
                    enter-to-class="max-h-[2000px] opacity-100"
                    leave-active-class="transition-all ease-in duration-150 overflow-hidden"
                    leave-from-class="max-h-[2000px] opacity-100"
                    leave-to-class="max-h-0 opacity-0"
                >
                    <div v-if="isExpanded(calc.id)" class="border-t border-gray-100">

                        <!-- Section: Formula info -->
                        <div class="px-5 py-4 bg-gray-50 border-b border-gray-100 flex flex-wrap gap-x-6 gap-y-2 text-sm">
                            <div>
                                <span class="text-xs font-medium text-gray-400 uppercase tracking-wide">Formula version</span>
                                <p class="font-mono font-medium text-gray-800 mt-0.5">{{ calc.formula_version ?? 'Unknown' }}</p>
                            </div>
                            <div>
                                <span class="text-xs font-medium text-gray-400 uppercase tracking-wide">Calculation date</span>
                                <p class="text-gray-800 mt-0.5">{{ formatDate(calc.created_at) }}</p>
                            </div>
                            <div>
                                <span class="text-xs font-medium text-gray-400 uppercase tracking-wide">Calculation ID</span>
                                <p class="font-mono text-gray-800 mt-0.5">#{{ calc.id }}</p>
                            </div>
                        </div>

                        <div class="px-5 py-5 space-y-6">

                            <!-- Section: Input values -->
                            <div>
                                <div class="flex items-center gap-2 mb-3">
                                    <span class="w-2 h-2 rounded-full bg-blue-400 shrink-0"></span>
                                    <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Input values</p>
                                </div>
                                <div class="grid grid-cols-2 gap-2">
                                    <template v-if="calc.steps_json">
                                        <div
                                            v-for="step in inputSteps(calc.steps_json)"
                                            :key="step.name"
                                            class="flex items-center justify-between bg-blue-50 rounded-lg px-3 py-2.5"
                                        >
                                            <span class="text-sm text-blue-800 font-medium">{{ step.name }}</span>
                                            <span class="text-sm font-mono text-blue-900">{{ formatNum(step.value, 2) }}</span>
                                        </div>
                                    </template>
                                    <template v-else>
                                        <div
                                            v-for="key in INPUT_KEYS"
                                            :key="key"
                                            class="flex items-center justify-between bg-blue-50 rounded-lg px-3 py-2.5"
                                        >
                                            <span class="text-sm text-blue-800 font-medium">{{ key }}</span>
                                            <span class="text-sm font-mono text-blue-900">
                                                {{ formatNum(calc.variables_json?.[key] ?? 0, 2) }}
                                            </span>
                                        </div>
                                    </template>
                                </div>
                            </div>

                            <!-- Section: Calculation steps -->
                            <template v-if="calc.steps_json && computedSteps(calc.steps_json).length">
                                <div>
                                    <div class="flex items-center gap-2 mb-3">
                                        <span class="w-2 h-2 rounded-full bg-brand-orange shrink-0"></span>
                                        <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Calculation steps</p>
                                    </div>
                                    <div class="space-y-2">
                                        <div
                                            v-for="(step, idx) in computedSteps(calc.steps_json)"
                                            :key="step.name"
                                            class="bg-orange-50 border border-orange-100 rounded-lg px-4 py-3"
                                        >
                                            <div class="flex items-start justify-between gap-4">
                                                <div class="min-w-0">
                                                    <div class="flex items-center gap-2 mb-1">
                                                        <span class="text-xs font-mono font-bold text-orange-700 bg-orange-100 rounded px-1.5 py-0.5">
                                                            Step {{ idx + 1 }}
                                                        </span>
                                                        <span class="text-sm font-semibold text-gray-800">{{ step.name }}</span>
                                                    </div>
                                                    <p class="text-xs font-mono text-gray-500 break-all">= {{ step.expression }}</p>
                                                </div>
                                                <div class="text-right shrink-0">
                                                    <p class="text-sm font-mono font-bold text-orange-700">{{ formatNum(step.value) }}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </template>

                            <!-- Section: Final result -->
                            <div>
                                <div class="flex items-center gap-2 mb-3">
                                    <span class="w-2 h-2 rounded-full bg-green-500 shrink-0"></span>
                                    <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Final result</p>
                                </div>
                                <div class="bg-green-50 border border-green-200 rounded-xl px-5 py-4">
                                    <p
                                        v-if="calc.steps_json && resultStep(calc.steps_json)"
                                        class="text-xs font-mono text-gray-500 mb-2"
                                    >
                                        {{ resultStep(calc.steps_json).expression }}
                                    </p>
                                    <div class="flex items-center justify-between">
                                        <span class="text-sm font-medium text-green-700">Commission</span>
                                        <span class="text-2xl font-bold text-green-800">
                                            £{{ formatNum(calc.commission) }}
                                        </span>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </Transition>
            </div>

            <!-- Pagination -->
            <div
                v-if="pagination && pagination.last_page > 1"
                class="flex items-center justify-between text-sm text-gray-600"
            >
                <span>
                    Showing {{ pagination.from }}–{{ pagination.to }} of {{ pagination.total }} calculations
                </span>
                <div class="flex items-center gap-1">
                    <button
                        @click="changePage(pagination.current_page - 1)"
                        :disabled="pagination.current_page === 1"
                        class="px-2 py-1 rounded hover:bg-white border border-gray-200 disabled:opacity-40 disabled:cursor-not-allowed transition"
                    >
                        <font-awesome-icon icon="chevron-left" class="text-xs" />
                    </button>
                    <span class="px-3 py-1 text-xs">
                        Page {{ pagination.current_page }} of {{ pagination.last_page }}
                    </span>
                    <button
                        @click="changePage(pagination.current_page + 1)"
                        :disabled="pagination.current_page === pagination.last_page"
                        class="px-2 py-1 rounded hover:bg-white border border-gray-200 disabled:opacity-40 disabled:cursor-not-allowed transition"
                    >
                        <font-awesome-icon icon="chevron-right" class="text-xs" />
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>
