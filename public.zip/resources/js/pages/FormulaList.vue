<template>
    <div class="min-h-screen bg-slate-50">
        <div class="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">

            <!-- Header -->
            <div class="mb-6 flex items-center justify-between">
                <div>
                    <h1 class="text-2xl font-bold text-brand-blue">Formulas</h1>
                    <p class="mt-1 text-sm text-slate-500">Manage and activate commission formula versions.</p>
                </div>
                <router-link
                    :to="{ name: 'formulas.create' }"
                    class="rounded-lg bg-brand-orange px-4 py-2.5 text-sm font-semibold text-white transition hover:opacity-90"
                >
                    + New formula
                </router-link>
            </div>

            <!-- Loading -->
            <div v-if="loading" class="rounded-2xl border border-slate-200 bg-white p-10 text-center text-sm text-slate-400">
                Loading formulas…
            </div>

            <!-- Error -->
            <div v-else-if="error" class="rounded-2xl border border-red-200 bg-red-50 p-6 text-sm text-red-700">
                {{ error }}
            </div>

            <!-- Empty -->
            <div
                v-else-if="formulas.length === 0"
                class="rounded-2xl border border-dashed border-slate-200 bg-white p-14 text-center"
            >
                <p class="text-4xl">📐</p>
                <p class="mt-3 text-sm font-medium text-slate-600">No formulas yet</p>
                <p class="mt-1 text-xs text-slate-400">Create your first commission formula to get started.</p>
                <router-link
                    :to="{ name: 'formulas.create' }"
                    class="mt-4 inline-block rounded-lg bg-brand-orange px-4 py-2 text-sm font-semibold text-white transition hover:opacity-90"
                >
                    Create formula
                </router-link>
            </div>

            <!-- Formula list -->
            <div v-else class="space-y-3">
                <div
                    v-for="formula in sortedFormulas"
                    :key="formula.id"
                    class="flex overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"
                >
                    <!-- Active accent bar -->
                    <div class="w-1 shrink-0 transition-colors" :class="formula.is_active ? 'bg-green-500' : 'bg-slate-200'"></div>

                    <div class="flex flex-1 flex-col gap-3 p-5 sm:flex-row sm:items-center sm:justify-between">
                        <!-- Left: info -->
                        <div class="min-w-0 flex-1">
                            <div class="flex flex-wrap items-center gap-2">
                                <span class="rounded-md bg-slate-100 px-2 py-0.5 font-mono text-xs font-semibold text-slate-600">
                                    v{{ formula.version }}
                                </span>
                                <span
                                    class="rounded-full px-2 py-0.5 text-xs font-medium"
                                    :class="formula.is_active ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'"
                                >
                                    {{ formula.is_active ? 'Active' : 'Inactive' }}
                                </span>
                                <span v-if="formula.dependent_variables?.length" class="text-xs text-slate-400">
                                    {{ formula.dependent_variables.length }} sub-variable{{ formula.dependent_variables.length !== 1 ? 's' : '' }}
                                </span>
                            </div>

                            <p class="mt-2 truncate rounded-md bg-slate-50 px-2.5 py-1.5 font-mono text-xs text-slate-600">
                                {{ formula.expression }}
                            </p>

                            <p class="mt-2 text-xs text-slate-400">
                                Created {{ formatDate(formula.created_at) }}
                            </p>
                        </div>

                        <!-- Right: actions -->
                        <div class="shrink-0">
                            <template v-if="formula.is_active">
                                <span class="rounded-lg border border-green-200 bg-green-50 px-4 py-2 text-xs font-semibold text-green-700">
                                    Currently active
                                </span>
                            </template>

                            <template v-else>
                                <!-- Confirm step -->
                                <div
                                    v-if="confirmingId === formula.id"
                                    class="flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2"
                                >
                                    <span class="text-xs font-medium text-amber-800">Activate this version?</span>
                                    <button
                                        @click="confirmActivate(formula.id)"
                                        class="rounded-md bg-brand-orange px-2.5 py-1 text-xs font-semibold text-white transition hover:opacity-90"
                                    >Yes</button>
                                    <button
                                        @click="confirmingId = null"
                                        class="rounded-md border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-600 transition hover:bg-slate-50"
                                    >Cancel</button>
                                </div>

                                <!-- Activate trigger -->
                                <button
                                    v-else
                                    @click="confirmingId = formula.id"
                                    class="rounded-lg border border-brand-blue/20 px-4 py-2 text-xs font-medium text-brand-blue transition hover:border-brand-blue/40 hover:bg-brand-blue/5"
                                >
                                    Activate
                                </button>
                            </template>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { useToast } from 'vue-toast-notification';
import useFormulas from '../composables/useFormulas.js';

const toast = useToast();
const { formulas, loading, error, fetchFormulas, activateFormula } = useFormulas();

const confirmingId = ref(null);

const sortedFormulas = computed(() =>
    [...formulas.value].sort((a, b) => {
        if (a.is_active !== b.is_active) return a.is_active ? -1 : 1;
        return b.id - a.id;
    })
);

async function confirmActivate(id) {
    const result = await activateFormula(id);
    confirmingId.value = null;
    if (result) {
        toast.success('Formula activated successfully.', { position: 'top-right', duration: 3000 });
    } else {
        toast.error(error.value || 'Failed to activate formula.', { position: 'top-right', duration: 3000 });
    }
}

function formatDate(dateStr) {
    if (!dateStr) return '—';
    return new Date(dateStr).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

onMounted(fetchFormulas);
</script>
