<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CommissionController;
use App\Http\Controllers\ContractController;
use App\Http\Controllers\FormulaController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('/register', [AuthController::class, 'register']);
Route::post('/login',    [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout',          [AuthController::class, 'logout']);
    Route::get('/profile',          [AuthController::class, 'profile']);
    Route::put('/updateProfile',    [AuthController::class, 'updateProfile']);
    Route::put('/updatePassword',   [AuthController::class, 'updatePassword']);

    Route::apiResource('contracts', ContractController::class);
    Route::post('/contracts/{contract}/calculate',     [CommissionController::class, 'calculate']);
    Route::get('/contracts/{contract}/calculations',  [CommissionController::class, 'history']);

    Route::get('/formulas',                    [FormulaController::class, 'index']);
    Route::post('/formulas',                   [FormulaController::class, 'store']);
    Route::post('/formulas/{id}/activate',     [FormulaController::class, 'activate']);
});
