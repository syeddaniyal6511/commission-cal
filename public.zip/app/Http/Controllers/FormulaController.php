<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreFormulaRequest;
use App\Services\FormulaService;
use Illuminate\Http\JsonResponse;

class FormulaController extends Controller
{
    public function __construct(private readonly FormulaService $formulaService) {}

    public function index(): JsonResponse
    {
        return response()->json($this->formulaService->index());
    }

    public function store(StoreFormulaRequest $request): JsonResponse
    {
        $formula = $this->formulaService->store($request->validated());

        return response()->json($formula, 201);
    }

    public function activate(int $id): JsonResponse
    {
        $formula = $this->formulaService->activate($id);

        return response()->json($formula);
    }
}
