<?php

namespace App\Http\Controllers;

use App\Models\Contract;
use App\Models\CommissionCalculation;
use App\Services\CommissionEngineService;
use Illuminate\Http\JsonResponse;

class CommissionController extends Controller
{
    public function calculate(Contract $contract, CommissionEngineService $engine): JsonResponse
    {
        $result = $engine->calculate($contract);

        $calculation = CommissionCalculation::create([
            'contract_id'     => $contract->id,
            'formula_id'      => $result['formula_id'],
            'formula_version' => $result['formula_version'],
            'commission'      => $result['commission'],
            'variables_json'  => $result['variables'],
            'steps_json'      => $result['steps'],
        ]);

        return response()->json([
            'contract_no'     => $contract->contract_no,
            'commission'      => $result['commission'],
            'variables'       => $result['variables'],
            'steps'           => $result['steps'],
            'formula_version' => $result['formula_version'],
            'calculation_id'  => $calculation->id,
            'calculated_at'   => $calculation->created_at,
        ]);
    }

    public function history(Contract $contract): JsonResponse
    {
        $calculations = CommissionCalculation::where('contract_id', $contract->id)
            ->latest()
            ->paginate(20);

        return response()->json($calculations);
    }
}
