<?php

namespace App\Services;

use App\Models\Formula;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;

class FormulaService
{
    public function index(): Collection
    {
        return Formula::with('dependentVariables')
            ->orderByDesc('is_active')
            ->orderByDesc('id')
            ->get();
    }

    public function activate(int $id): Formula
    {
        return DB::transaction(function () use ($id) {
            Formula::query()->update(['is_active' => false]);
            $formula = Formula::findOrFail($id);
            $formula->update(['is_active' => true]);
            return $formula->load('dependentVariables');
        });
    }

    public function store(array $data): Formula
    {
        return DB::transaction(function () use ($data) {
            $formula = Formula::create([
                'version'    => $data['version'],
                'expression' => $data['expression'],
                'is_active'  => false,
            ]);

            foreach ($data['variables'] ?? [] as $index => $var) {
                $formula->dependentVariables()->create([
                    'name'            => $var['name'],
                    'expression'      => $var['expression'],
                    'execution_order' => $var['execution_order'] ?? $index,
                ]);
            }

            return $formula->load('dependentVariables');
        });
    }
}
