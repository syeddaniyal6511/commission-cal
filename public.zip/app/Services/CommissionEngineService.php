<?php

namespace App\Services;

use App\Models\Contract;
use App\Models\Formula;
use Symfony\Component\ExpressionLanguage\ExpressionLanguage;

class CommissionEngineService
{
    protected ExpressionLanguage $el;

    public function __construct()
    {
        $this->el = new ExpressionLanguage();
    }

    public function calculate(Contract $contract): array
    {
        $formula = Formula::where('is_active', true)
            ->with(['dependentVariables' => fn ($q) => $q->orderBy('execution_order')])
            ->firstOrFail();

        $variables = [
            'AnnualUsage'    => (float) $contract->annual_usage,
            'ContractValue'  => (float) $contract->contract_value,
            'ContractLength' => (int)   $contract->contract_length,
            'RiskScore'      => (float) $contract->risk_score,
        ];

        $steps = [];

        foreach ($variables as $name => $value) {
            $steps[] = ['type' => 'input', 'name' => $name, 'value' => $value];
        }

        foreach ($formula->dependentVariables as $var) {
            $value                 = $this->el->evaluate($var->expression, $variables);
            $variables[$var->name] = $value;

            $steps[] = [
                'type'       => 'computed',
                'name'       => $var->name,
                'expression' => $var->expression,
                'value'      => $value,
            ];
        }

        $commission = $this->el->evaluate($formula->expression, $variables);

        $steps[] = [
            'type'       => 'result',
            'expression' => $formula->expression,
            'value'      => $commission,
        ];

        return [
            'commission'      => $commission,
            'variables'       => $variables,
            'steps'           => $steps,
            'formula_id'      => $formula->id,
            'formula_version' => $formula->version,
        ];
    }
}
